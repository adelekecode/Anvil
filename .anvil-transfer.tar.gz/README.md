# Anvil

Offline-first, end-to-end encrypted, real-time group voice between nearby
devices. No internet, no cellular, no accounts, no servers.

Anvil finds the people near you over whatever local path exists — an ordinary
Wi-Fi network with the internet unplugged, or Wi-Fi Aware when there is no router
at all — and keeps the conversation going when that path changes underneath it.

**Status: Phase 0.** The architecture, interfaces, protocol documentation and the
full app UX are in place, along with the parts that are pure logic and testable
without a device: path scoring and failover, discovery de-duplication, packet
parsing, replay rejection, jitter buffering, VAD, mixing, relay election, room
state, trust-on-first-use, join codes and the call state machine. Networking,
real cryptography and audio I/O land in Phases 1–3.

## No accounts

There is no signup, no login, no password, no phone number and no server — not
as an omission but as the architecture. On first launch the user types a display
name; Anvil generates a keypair on the device and that is the whole of
onboarding.

```
  Install  →  "Display name: [ Femi ]"  →  keypair generated locally  →  ready
  Reopen   →  load local identity       →  discovery starts           →  ready
```

| Conventional | Anvil |
|---|---|
| account | a keypair |
| user id | `PeerId`, derived from the public key |
| login | loading the local profile |
| session token | nothing |
| display name | a label, deliberately *not* an identity |

Two people can both be "Femi". Anvil knows they are `anv_a82…` and `anv_c93…`,
and shows a fingerprint (`7A:42:19:BC`) when it matters. Trust is
trust-on-first-use: a peer presenting a **different key for a name you already
trust** raises an explicit warning rather than being silently accepted. See
[`protocol/identity.md`](protocol/identity.md) for what that does and does not
defend against.

## Why the pieces are where they are

```
  Flutter          screens, controls, state display
      │  commands in, events out — never protocol state
  Rust core        identity · rooms · crypto · media · transport · relay
      │  capabilities in, platform events out
  Kotlin / Swift   Wi-Fi Aware · LAN · microphone · lifecycle
      │
  Wi-Fi LAN  ·  Wi-Fi Aware
```

Three rules hold this together, and everything else follows from them:

**A room is not a connection.** `RoomId`, `PeerId`, `StreamId`, sequence state and
key epochs are defined independently of any socket, IP or radio. Unplug the
router mid-sentence and the room does not notice.

**A relay is not an authority.** Group rooms route media through one elected
participant, who forwards sealed packets and holds no media keys. Replacing them
changes nothing cryptographic.

**The core decides, the platform performs.** Transport selection, failover,
election, identity and media timing are decided once in Rust for both platforms.
There is no `#[cfg(target_os)]` in the protocol.

## Layout

```
crates/anvil-core/     the protocol — everything that decides what Anvil does
  identity/            local profile, fingerprints, known peers, TOFU
  peer/                per-peer relationship and the call state machine
  chat/                messages and local history
crates/anvil-ffi/      C ABI bridge (Flutter via dart:ffi, and the adapters)
apps/mobile/lib/       Flutter app (first run, home, peer, call, chat, room)
apps/mobile/android/   Kotlin adapters
apps/mobile/ios/       Swift adapters
protocol/              the specification
tests/                 device test plans that cannot be automated
```

## Building

```bash
cargo test --workspace          # 295 tests, no device or network needed
cd apps/mobile && flutter test  # event decoding across the FFI boundary
cargo clippy --workspace --all-targets
```

Optional features, off by default so the scaffold builds on a bare toolchain:

| Feature | Brings in | Phase |
|---|---|---|
| `crypto` | Ed25519, X25519, HKDF, ChaCha20-Poly1305 | 2 |
| `quic` | quinn + rustls | 1 |
| `opus` | libopus via a C build | 1 |

The Flutter app needs the Rust library built for the target platform first; that
build wiring is Phase 0 work still to do (see below).

## Reading order

New to the project? In this order:

1. [`protocol/specification.md`](protocol/specification.md) — the three
   invariants and the document map.
2. [`crates/anvil-core/src/lib.rs`](crates/anvil-core/src/lib.rs) — the crate
   docs explain the shape.
3. [`crates/anvil-core/src/transport/`](crates/anvil-core/src/transport/) — path
   scoring and failover, the most interesting logic in the project and fully
   tested.
4. [`protocol/encryption.md`](protocol/encryption.md) — including a frank account
   of what the v0.1 sender-key scheme costs.
5. [`protocol/identity.md`](protocol/identity.md) — the no-accounts model, and
   the limits of trust-on-first-use and join codes.

## Phases

| Phase | Goal | State |
|---|---|---|
| 0 | Repository, interfaces, protocol docs | **this** |
| 1 | LAN proof of concept: discovery, QUIC, Opus, real audio | next |
| 2 | Encryption: identity, handshake, sender keys, epochs | |
| 3 | Relay: scoring, election, encrypted fan-out, failover | |
| 4 | Android Wi-Fi Aware | |
| 5 | iOS Wi-Fi Aware and cross-platform interop | **highest risk** |
| 6 | Adaptive transport: both paths live, failover between them | |
| 7 | Audio tuning | |
| 8 | Reliability and stress | |

The success criterion is unchanged: **three or four phones, no internet, a secure
group conversation** — working both on a router with the WAN unplugged and over
Wi-Fi Aware with no router at all.

### Known risks, stated up front

**iOS Wi-Fi Aware interop is the schedule risk.** Apple's peer-to-peer Wi-Fi story
has historically been AWDL exposed indirectly, not a directly programmable NAN
API of the kind Android offers. Whether an iPhone and an Android phone can find
each other and establish a data path is an empirical question that should be
answered with a throwaway probe on two devices *before* Phase 5 depends on it.
The fallback costs no protocol change — one device hosts a local network and the
others join it as a LAN path — and is described in
[`WifiAwareAdapter.swift`](apps/mobile/ios/Runner/WifiAwareAdapter.swift).

**Sender keys do not scale past small rooms.** O(n²) key deliveries on every
membership change. Fine at four people, not at twelve. The `GroupKeyManager`
abstraction exists so MLS can replace it without touching the media pipeline.

## Still to do in Phase 0

- Rust build wiring for Android (cargo-ndk, jniLibs) and iOS (xcframework), plus
  the Flutter platform channel that hands the session pointer to the adapters.
- The JNI and Swift entry points the adapters call to submit platform events.
- Flutter widget tests over the event decoding.
- CI: `cargo test`, `cargo clippy`, `flutter analyze`.
